using AmongUs.GameOptions;
using Hazel;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using TownOfHost.Modules;

namespace TownOfHost.Roles.Impostor;

public sealed class Undertaker
    : RoleBase, IImpostor, IUsePhantomButton
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Undertaker),
            player => new Undertaker(player),
            CustomRoles.Undertaker,
            () => RoleTypes.Phantom,
            CustomRoleTypes.Impostor,
            13960,
            SetupOptionItem,
            "ut",
            "#A0522D",
            (1, 2),
            introSound: () => GetIntroSound(RoleTypes.Impostor),
            from: From.None
        );

    private static OptionItem OptionCooldown;
    private static OptionItem OptionDuration;
    static float cooldownMax;
    static float durationMax;

    private bool isDragging;
    private byte savedPlayerId;
    private float cooldownTimer;
    private float dragTimer;

    public Undertaker(PlayerControl player)
    : base(RoleInfo, player)
    {
        cooldownMax = OptionCooldown.GetFloat();
        durationMax = OptionDuration.GetFloat();
        isDragging = false;
        savedPlayerId = byte.MaxValue;
        cooldownTimer = 0f;
        dragTimer = 0f;
    }

    bool IUsePhantomButton.IsPhantomRole =>
        isDragging || cooldownTimer <= 0f;

    enum OptionName
    {
        OptionCooldown,
        OptionDuration
    }

    private static void SetupOptionItem()
    {
        OptionCooldown = FloatOptionItem.Create(
            RoleInfo, 7961, OptionName.OptionCooldown,
            new(0f, 60f, 2f), 10f, false);
        OptionDuration = FloatOptionItem.Create(
            RoleInfo, 7962, OptionName.OptionDuration,
            new(1f, 30f, 1f), 10f, false);
    }

    public void OnClick(
        ref bool AdjustKillCooldown,
        ref bool? ResetCooldown)
    {
        AdjustKillCooldown = false;
        ResetCooldown = true;

        if (cooldownTimer > 0f && !isDragging) return;

        if (isDragging)
        {
            isDragging = false;

            if (AmongUsClient.Instance.AmHost &&
                savedPlayerId != byte.MaxValue)
            {
                PlayerControl targetControl = null;
                foreach (var p in PlayerControl.AllPlayerControls)
                {
                    if (p != null && p.PlayerId == savedPlayerId)
                    {
                        targetControl = p;
                        break;
                    }
                }

                if (targetControl != null && targetControl.Data != null)
                {
                    // ★【確定修正】バニラ公式の死体リスポーンRPCに完全適合
                    if (ShipStatus.Instance != null)
                    {
                        ShipStatus.Instance.RpcSpawnDeadBody(
                            targetControl.Data,
                            Player.transform.position,
                            false);
                    }
                }
            }

            savedPlayerId = byte.MaxValue;
            cooldownTimer = cooldownMax;
            dragTimer = 0f;
            SendRPC();
            UtilsNotifyRoles.NotifyRoles(Player);
            return;
        }

        var bodies = Object.FindObjectsOfType<DeadBody>();
        DeadBody closestBody = null;
        float minDistance = 2.0f;

        foreach (var body in bodies)
        {
            if (body == null) continue;
            float dist = Vector2.Distance(
                Player.transform.position,
                body.transform.position);

            if (dist < minDistance)
            {
                minDistance = dist;
                closestBody = body;
            }
        }

        if (closestBody != null)
        {
            isDragging = true;
            savedPlayerId = closestBody.ParentId;

            if (AmongUsClient.Instance.AmHost)
            {
                Object.Destroy(closestBody.gameObject);
            }

            cooldownTimer = 0f;
            dragTimer = durationMax;
            SendRPC();
            UtilsNotifyRoles.NotifyRoles(Player);
        }
    }

    public override void OnFixedUpdate(PlayerControl player)
    {
        if (!AmongUsClient.Instance.AmHost) return;
        if (!Player.IsAlive())
        {
            if (isDragging && savedPlayerId != byte.MaxValue)
            {
                PlayerControl targetControl = null;
                foreach (var p in PlayerControl.AllPlayerControls)
                {
                    if (p != null && p.PlayerId == savedPlayerId)
                    {
                        targetControl = p;
                        break;
                    }
                }
                if (targetControl != null && targetControl.Data != null)
                {
                    if (ShipStatus.Instance != null)
                    {
                        ShipStatus.Instance.RpcSpawnDeadBody(
                            targetControl.Data,
                            Player.transform.position,
                            false);
                    }
                }
            }
            isDragging = false;
            savedPlayerId = byte.MaxValue;
            return;
        }

        if (cooldownTimer > 0f && !isDragging)
            cooldownTimer -= Time.fixedDeltaTime;

        if (isDragging && savedPlayerId != byte.MaxValue)
        {
            if (dragTimer > 0f)
            {
                dragTimer -= Time.fixedDeltaTime;

                if (dragTimer <= 0f)
                {
                    isDragging = false;

                    PlayerControl targetControl = null;
                    foreach (var p in PlayerControl.AllPlayerControls)
                    {
                        if (p != null && p.PlayerId == savedPlayerId)
                        {
                            targetControl = p;
                            break;
                        }
                    }

                    if (targetControl != null && targetControl.Data != null)
                    {
                        if (ShipStatus.Instance != null)
                        {
                            ShipStatus.Instance.RpcSpawnDeadBody(
                                targetControl.Data,
                                Player.transform.position,
                                false);
                        }
                    }

                    savedPlayerId = byte.MaxValue;
                    cooldownTimer = cooldownMax;
                    SendRPC();
                    UtilsNotifyRoles.NotifyRoles(Player);
                }
            }
        }
    }

    public override void OnSpawn(bool initialState)
    {
        isDragging = false;
        savedPlayerId = byte.MaxValue;
        dragTimer = 0f;
        if (Player.IsAlive())
        {
            SendRPC();
        }
    }

    private void SendRPC()
    {
        using var sender = CreateSender();
        sender.Writer.Write(isDragging);
        sender.Writer.Write(savedPlayerId);
        sender.Writer.Write(cooldownTimer);
        sender.Writer.Write(dragTimer);
    }

    public override void ReceiveRPC(MessageReader reader)
    {
        isDragging = reader.ReadBoolean();
        savedPlayerId = reader.ReadByte();
        cooldownTimer = reader.ReadSingle();
        dragTimer = reader.ReadSingle();
    }

    public override string GetProgressText(
        bool comms = false,
        bool gamelog = false)
    {
        if (isDragging)
        {
            int remain = Mathf.CeilToInt(dragTimer);
            return Utils.ColorString(Color.red,
                $"[隠密中: 残り {remain}s]");
        }
        if (cooldownTimer > 0f)
        {
            int c = Mathf.CeilToInt(cooldownTimer);
            return Utils.ColorString(Color.gray, $"({c}s)");
        }
        return Utils.ColorString(RoleInfo.RoleColor, "[READY]");
    }

    public override string GetAbilityButtonText() =>
        isDragging ? "Undertaker_AbilityButton" : "UndertakerAbility";

    public override bool OverrideAbilityButton(out string text)
    {
        text = "Undertaker_Ability";
        return true;
    }
}
